export interface Ex5CompressorDetailUIModel {
    
    compId: number;  
    name: string;
    checkedStatus: boolean,
    compType: string;
    sealType: string;
    sealTemperature: DoubleRange;
    heightOfAwayfromkey:number;
    heightOfsupportnearkey:number;
    jbavg:DoubleRange;
    enabled:boolean,
  }