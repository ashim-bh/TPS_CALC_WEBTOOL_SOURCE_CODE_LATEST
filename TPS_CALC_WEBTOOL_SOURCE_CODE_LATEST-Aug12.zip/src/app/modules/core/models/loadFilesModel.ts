export interface loadFilesModelData {
  
    
    staLocCo1P1:string,
    staLocCo1P2:string;
    staLocCo1P3:string;
    staLocCo2P1:string;
    staLocCo2P2:string;
    staLocCo2P3:string;
    staLocCo3P1:string;
    staLocCo3P2:string;
    staLocCo3P3:string;
    stdLocCo1:string;
    stdLocCo2:string;
    stdLocCo3:string;
  }
  