export interface StatBot {
jobRecId:any,
  password: string,
  ssoid: string,
  status: string,
  toolId: number
}