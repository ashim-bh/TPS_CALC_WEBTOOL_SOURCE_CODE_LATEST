export interface BOtStatus {
    enabled1: boolean;
    value1: string;
    
  
}