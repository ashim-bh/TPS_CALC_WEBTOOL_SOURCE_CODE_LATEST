export interface VersionUIModel {
    enabled: boolean;
    value: number;
}
