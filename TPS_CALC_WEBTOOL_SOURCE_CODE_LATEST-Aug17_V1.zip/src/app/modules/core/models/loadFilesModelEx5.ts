export interface loadFilesModelDataEx5 {
  
  co1Prt1Prtpath:string;
  co2Prt2Prtpath:string;
  co3Prt3Prtpath:string;
  }
  