export interface Ex5CompressorDetailUIModel {
    
    compId: number;  
    name: string;
    checkedStatus: boolean,
    compType: string;
    sealType: string;
    sealTemperature: number ;
    heightOfAwayfromkey:number;
    heightOfsupportnearkey:number;
    jbavg:number;
    enabled:boolean,
  }