import { TpsNumberFormatterPipe } from './tps-number-formatter.pipe';

describe('TpsNumberFormatterPipe', () => {
  it('create an instance', () => {
    const pipe = new TpsNumberFormatterPipe();
    expect(pipe).toBeTruthy();
  });
});
