export interface Ex5CompressorDetailUIModel {
    
    compId: number;  
    name: string;
    checkedStatus: boolean,
    compType: string;
    sealType: string;
    sealTemperature: number;
    heightOfAwayfromkey:any;
    heightOfsupportnearkey:any;
    jbavg:number;
    enabled:boolean,
  }