export interface UserDetails {
    ssoidOrBhid: string,
    mail: string,
    owner: string,
    password: string,
    
}
