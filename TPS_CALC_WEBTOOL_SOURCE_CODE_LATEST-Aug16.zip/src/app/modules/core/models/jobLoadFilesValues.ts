export interface jobLoadFilesValues{
    
}